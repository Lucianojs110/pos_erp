<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Accounting\\Providers\\AccountingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Accounting\\Providers\\AccountingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);