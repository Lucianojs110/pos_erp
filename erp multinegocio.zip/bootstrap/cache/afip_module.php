<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Afip\\Providers\\AfipServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Afip\\Providers\\AfipServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);