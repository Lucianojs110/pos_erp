<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AiAssistance\\Providers\\AiAssistanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AiAssistance\\Providers\\AiAssistanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);